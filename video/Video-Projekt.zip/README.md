# Video-Projekt

Installation: `python3 -m pip install Pillow imageio-ffmpeg`

Start: `python3 render.py`

Das Ergebnis liegt in `output/`. 30 Kapitel, 6:30 Minuten, 1280×720, 24 fps, keine Audiospur. Originale Bildschirmaufnahmen bleiben bei ihrer gemessenen Geschwindigkeit; kurze Auszüge werden für die Kapitel wiederholt. Alle Screenshots zeigen öffentliche Beispieldaten. Schriftlizenzen im Ordner fonts.
