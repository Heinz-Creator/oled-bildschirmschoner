from PIL import Image,ImageDraw,ImageFont,ImageOps
from pathlib import Path
import subprocess,json,sys,math
ROOT=Path(__file__).resolve().parent
BASE=Path(__file__).resolve().parent
OUT=BASE/'output'
OUT.mkdir(exist_ok=True)
import imageio_ffmpeg
FF=imageio_ffmpeg.get_ffmpeg_exe()
FONT=BASE/'fonts'
body=ImageFont.truetype(str(FONT/'dmsans.ttf'),23)
small=ImageFont.truetype(str(FONT/'dmsans.ttf'),16)
heading=ImageFont.truetype(str(FONT/'barlow.ttf'),42)
label=ImageFont.truetype(str(FONT/'dmsans.ttf'),17)
# Screen recordings retain their measured source timestamps. No audio track is created.
chapters=[
('Dein Zuhause wird lebendig.','Ein eigenständiger Bildschirmschoner für Home Assistant: echte Hausdaten, illustrierte Motive, animierte Ereignisse und eigene Fotos. Dieser Rundgang zeigt Beispieldaten. Es werden keine Geräte gesteuert.','tree-laundry.jpg',None),
('Installieren mit HACS','Repository Heinz-Creator/oled-bildschirmschoner als benutzerdefiniertes Dashboard-Repository hinzufügen. Herunterladen, Browser neu laden und die Karte im eigenen Dashboard hinzufügen. Bilder und Klänge kommen mit dem Paket.','einstellungen-anzeige.jpg',None),
('Auf deinem Display starten','Bildschirmschoner einstellen öffnen. Automatisch starten aktivieren und die Ruhezeit wählen. Das Dashboard muss geöffnet und das Display eingeschaltet bleiben. Die Startschaltfläche im Dashboard ist optional.','einstellungen-anzeige.jpg',None),
('Ein Menü für alle Welten','Anzeige, Meldungen, Musik und Fotoalben: Die gemeinsamen Einstellungen gelten für die ausgewählten Motive auf diesem Display. Bildauswahl und Wechselintervall haben jeweils genau eine Stelle.','einstellungen-anzeige.jpg',None),
('Klassisch oder animiert','Baum & Jahreszeiten, Minecraft-Welt, Lichtküste und Die kleine Nachtbahn. Bisherige Motive bleiben getrennt von den zusätzlichen Animierten Welten. Klassische Illustrationen erhalten keine allgemeine Sackkarrenfigur.','christmas.jpg',None),
('Die animierte Waldwelt','Eine fertige Waschmaschine wird als Szene mit Waldbewohnern und Wäscheleine gezeigt. Die Ereignisse gehören zur gewählten Welt. Diese kurze Aufnahme stammt aus der echten Karten-Vorschau.','tree-laundry.jpg','wald'),
('An der Lichtküste','Der Geschirrspüler ist fertig. Die Küstenwelt verwendet eine andere, zu ihrer Landschaft passende Szene. Größe, Ort und Bildsprache unterscheiden sich von der Waldwelt.','coast-dishes.jpg','kueste'),
('Die Blockwelt','Müll, Geräte, Besuch und Solar-Laden erhalten eigene Darstellungen im Blockstil. Das Motiv ist eine inoffizielle Projektillustration. Kein Bezug zu Mojang oder Microsoft.','minecraft-waste.jpg','blockwelt'),
('Die kleine Nachtbahn','Die Bahn bewegt sich durch die Landschaft. Eine Besuchsmeldung bekommt sofort Vorrang vor den anderen Ereignissen. Hier: Besuch am Bahnhof, als reine Funktionsvorschau ohne Klingel oder Durchsage.','railway-visitor.jpg','bahn'),
('Vier Jahreszeiten','Frühling, Sommer, Herbst und Winter wechseln automatisch nach Datum. Die drei Kunstwelten enthalten zusammen 84 Tag-, Nacht-, Saison- und Feiertagsbilder. Die Nachtbahn ergänzt diese Auswahl.','christmas.jpg',None),
('Tag, Nacht und echtes Wetter','Standard ist automatisch nach Sonnenstand aus Home Assistant. Immer Tag und Immer Nacht sind ebenfalls wählbar. Regen und Schnee folgen den gemeldeten Wetterdaten; reduzierte Bewegung wird berücksichtigt.','einstellungen-anzeige.jpg',None),
('Feiertage auswählen','Advent, Weihnachten, Nikolaus, Silvester, Valentinstag, Ostern, Muttertag, Vatertag, Pfingsten, Einheit und Halloween. Einzelne Anlässe lassen sich ausschalten. Osterhase und Weihnachtsmann ergänzen passende Szenen.','easter.jpg',None),
('Gerade im Haus','Licht und Rollos werden in Kategorien mit kräftigen Überschriften dargestellt. Medien, Hausverbrauch und PV kommen aus den gewählten HA-Quellen. Unbekannte Werte werden nicht als bestätigte Zustände erfunden.','christmas.jpg',None),
('Eigene Ereignisse zuordnen','Unter Meldungen eigene Sensoren und Auslösezustände wählen: Waschmaschine, Geschirrspüler, Müll, Solar-Laden und Besuch. Die Regeln gelten über alle Motive hinweg. Testschalter erzeugen nur visuelle Beispiele.','einstellungen-klingel.jpg',None),
('Mehrere Meldungen zugleich','Besuch unterbricht sofort. Danach wechseln die übrigen Ereignisse nacheinander. Die Anzeigedauer ist je Ereignis wählbar. Text mit Grafik oder nur Grafik lässt sich gemeinsam einstellen.','railway-visitor.jpg',None),
('Ablaufzeit oder Quittieren','Fertigmeldungen verschwinden nach der gewählten Zeit. Bei Bis aus / ohne Zeitlimit erscheint Quittieren. Eine quittierte Meldung bleibt weg, bis der nächste erkannte Gerätezyklus eine neue Meldung erzeugt.','tree-laundry.jpg',None),
('Müll: vorher und am Abholtag','Am Vortag erinnert die Karte ans Rausstellen, am Termin an die Abholung. Wiederholung bedeutet erneutes Anzeigen nach der Pause. Abgeholt zählt erst nach einer Bestätigung, nicht allein nach Datum.','minecraft-waste.jpg',None),
('Geräte ohne Fertigsensor','Im Karteneditor eine geeignete Messsteckdose mit Leistungssensor in Watt wählen. Start- und Ende-Schwellen sowie Wartezeiten einstellen. Die Karte erstellt Status-Helfer und Automation; die Steckdose bleibt eingeschaltet.','einstellungen-klingel.jpg',None),
('Musik startet nur auf Knopfdruck','Oben befinden sich Start und Stop. Music Assistant, Alexa Devices oder Alexa Media Player können je nach eigener Integration passende Musik anfordern. Ein Motivwechsel startet keine Wiedergabe. In diesem Video bleibt alles stumm.','einstellungen-musik.jpg',None),
('Titel, Cover und YouTube','Titel, Interpret und Cover kommen vom gewählten Player, wenn er sie liefert. Stop beendet oder pausiert dessen Wiedergabe. Eigene YouTube-Playlist-Links spielen alternativ im eingeblendeten Player auf diesem Display.','einstellungen-musik.jpg',None),
('Die Haustürklingel einrichten','Eigenen Klingelsensor und Lautsprecher auswählen. Bei Zustandsentitäten den echten Klingelzustand eintragen. Event-Entitäten verwenden den Empfang eines Ereignisses. Zum Speichern sind HA-Administratorrechte erforderlich.','einstellungen-klingel.jpg',None),
('Ansage, Klingelmusik oder stumm','Assist-Satellit mit seiner konfigurierten Stimme oder Mediaplayer mit eigener TTS-Entität. Sechs Klangoptionen sind enthalten: vier kurze Motivklänge und zwei Musik-Jingles. Speichern spielt keinen Ton ab.','einstellungen-klingel.jpg',None),
('Auch ohne offenes Dashboard','Die Klingel-Audioautomation läuft zentral in Home Assistant. Das Bildschirmbild braucht dagegen ein offenes Display. Bestehende Klingelansagen prüfen, damit nicht zwei Automationen gleichzeitig sprechen. Kamera und Telefonie bleiben eigene HA-Funktionen.','einstellungen-klingel.jpg',None),
('Deine eigenen Fotoalben','Mehrere Bilder, ganze Ordner oder Album-ZIPs importieren. Alben aktivieren und Reihenfolge oder Zufallswiedergabe wählen. Fotos können allein oder im Wechsel mit den Motivwelten laufen.','einstellungen-fotos.jpg',None),
('Google Fotos: zwei Wege','Ohne API: Google Takeout als ZIP oder Ordner importieren. Direkt: eigenes Google-Projekt mit Photos Picker API und OAuth-Client. Die Anleitung erklärt HTTPS-Ursprung, Testnutzer und Fotoauswahl. Keine private Vollalbum-Synchronisation.','einstellungen-fotos.jpg',None),
('Wo bleiben deine Bilder?','Albumimporte liegen im Browserspeicher dieses Displays und HA-Benutzers. Browserdaten löschen entfernt sie. Andere Displays benötigen einen eigenen Import. Google-Tokens werden nur für die laufende Auswahl im Arbeitsspeicher verwendet.','einstellungen-fotos.jpg',None),
('Der optionale Assistent','Edgar, Berta Berlin oder Haunting-Hector auswählen. Pro Figur einen eigenen HA-Assist-Assistenten zuordnen. Stimme und Sprachmodell kommen aus dessen Pipeline. Der gesamte Assistent lässt sich ausschalten.','figuren.jpg',None),
('Chat und bewusstes Zuhören','Der leuchtende Knopf öffnet Gesicht und Chat, ohne den Schoner zu beenden. Tippen oder eine Mikrofonrunde über Zuhören. Die öffentliche Karte bietet keine dauerhafte Mithörsitzung. Sprachausgabe benötigt eine funktionierende Assist-Pipeline.','assistant-berta.jpg',None),
('Frei konfigurieren. Weiterentwickeln.','Die ausführliche README erklärt alle Funktionen und Grenzen. Google-Fotos- und Klingelanleitung liegen separat bei. Updates über HACS bringen neue mitgelieferte Motive; deine lokalen Alben bleiben eigene Browserdaten.','einstellungen-anzeige.jpg',None),
('Jetzt dein Display gestalten.','github.com/Heinz-Creator/oled-bildschirmschoner\n\nInstallationsanleitung, Funktionen, Konfiguration und Prüfbericht stehen im Repository. Dieser Rundgang zeigt die öffentliche Version mit Beispieldaten und ohne Audioausgabe.','tree-laundry.jpg',None),
]
DURATION=13
W,H=1280,720

def wrapped(draw,text,font,width):
 result=[]
 for paragraph in text.split('\n'):
  if not paragraph:result.append('');continue
  line=''
  for word in paragraph.split():
   trial=(line+' '+word).strip()
   if draw.textlength(trial,font=font)>width and line:result.append(line);line=word
   else:line=trial
  if line:result.append(line)
 return result

def panel(index,title,copy,asset):
 im=Image.new('RGB',(W,H),'#08131e');d=ImageDraw.Draw(im)
 d.text((40,26),'OLED BILDSCHIRMSCHONER',font=label,fill='#d8c49f')
 d.text((40,63),title,font=heading,fill='#f5ebd8')
 for j,line in enumerate(wrapped(d,copy,body,332)):
  d.text((40,155+j*31),line,font=body,fill='#d6e1e2')
 photo=Image.open(BASE/asset).convert('RGB');photo.thumbnail((830,480),Image.Resampling.LANCZOS)
 x=420+(830-photo.width)//2;y=154+(480-photo.height)//2;im.paste(photo,(x,y))
 d.line((40,659,1240,659),fill='#29424b',width=1)
 d.text((40,678),'FUNKTIONSRUNDGANG · BEISPIELDATEN · OHNE AUDIO',font=small,fill='#a9bfc5')
 d.text((1110,678),f'{index+1:02d} / {len(chapters):02d}',font=small,fill='#d8c49f')
 return im

def run(args):subprocess.run([FF,'-nostdin','-v','error','-y',*args],check=True)
clips={}
for key in ['wald','bahn','kueste','blockwelt']:
 frames=json.loads((BASE/('capture-'+key)/'timing.json').read_text());lst=OUT/(key+'.ffconcat')
 lines=['ffconcat version 1.0']
 for i,f in enumerate(frames):
  f['file']=str((BASE/('capture-'+key)/Path(f['file']).name).resolve())
  dt=((frames[i+1]['at']-f['at'])/1000) if i+1<len(frames) else .15
  lines.extend(["file '"+f['file']+"'",'duration '+str(max(.02,dt))])
 lines.append("file '"+frames[-1]['file']+"'")
 lst.write_text('\n'.join(lines)+'\n');clip=OUT/(key+'.mp4');run(['-f','concat','-safe','0','-i',str(lst),'-vf','fps=24,scale=trunc(iw/2)*2:trunc(ih/2)*2','-an','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p',str(clip)]);clips[key]=clip
manifest=[]
for i,(title,copy,asset,clip) in enumerate(chapters):
 png=OUT/f'panel-{i:02d}.png';panel(i,title,copy,asset).save(png)
 output=OUT/f'chapter-{i:02d}.mp4'
 if clip:
  # Repeated short scene excerpt, always at the original recorded speed.
  args=['-loop','1','-framerate','24','-i',str(png),'-stream_loop','-1','-i',str(clips[clip]),'-filter_complex','[1:v]scale=830:480:force_original_aspect_ratio=decrease,pad=830:480:(ow-iw)/2:(oh-ih)/2:color=0x08131e[v];[0:v][v]overlay=420:154:shortest=1[out]','-map','[out]']
 else:
  # Gentle camera move over the authored panel, preserving all labels and framing.
  args=['-loop','1','-framerate','24','-i',str(png),'-vf',"zoompan=z='min(1.008,1+on*0.000025)':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=1:s=1280x720:fps=24"]
 run([*args,'-t',str(DURATION),'-an','-c:v','libx264','-preset','veryfast','-crf','21','-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709',str(output)])
 manifest.append({'index':i+1,'start':i*DURATION,'duration':DURATION,'title':title,'copy':copy,'asset':asset,'source_clip':clip});print(f'{i+1}/{len(chapters)} {title}',flush=True)
(OUT/'timeline.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(OUT/'chapters.ffconcat').write_text('ffconcat version 1.0\n'+''.join("file '"+str((OUT/f'chapter-{i:02d}.mp4').resolve())+"'\n" for i in range(len(chapters))))
final=OUT/'OLED-Bildschirmschoner-Ausfuehrlicher-Rundgang.mp4'
run(['-f','concat','-safe','0','-i',str(OUT/'chapters.ffconcat'),'-c','copy','-movflags','+faststart',str(final)])
(OUT/'youtube-kapitel.txt').write_text('\n'.join(f'{(i*DURATION)//60:02d}:{(i*DURATION)%60:02d} {title}' for i,(title,*_) in enumerate(chapters)))
print('FERTIG',final,final.stat().st_size,flush=True)
